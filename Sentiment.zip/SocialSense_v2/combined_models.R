# combined model performance
#Model 1

library("utils", lib.loc="C:/Personal/R/R-3.4.1/library")
library('RSentiment')
library('tm')
library('sentimentr')
library("textstem", lib.loc="C:/Personal/R/R-3.4.1/library")
library("stringr", lib.loc="C:/Personal/R/R-3.4.1/library")
library("sentiment", lib.loc="C:/Personal/R/R-3.4.1/library")
library("Rstem", lib.loc="C:/Personal/R/R-3.4.1/library")

# LOAD DATA FROM CSV

dat1 = read.csv("C:\\Personal\\My Projects\\Sentiment\\SocialSense_v2\\data\\sourcedata.csv",header=TRUE)

dat1[is.na(dat1)] = 0 #replace all NAs with 0 to prevent errors

Sample_data = rbind.data.frame(dat1) # compile multiple datasets into 1

Sample_data = dat1[!(is.na(dat1$text) | dat1$text==""), ] # compile multiple datasets into 1(if present)

tweets = Sample_data[c("text","Brand")]

r1 = tweets
#View(r1)
r1$CleanText <- ""


# Text preprocessing function
Clean_String <- function(string){
  #symbol replace
  temp = str_replace_all(string, "[^[:alnum:]]", " ")
  # Lowercase
  temp <- tolower(string)
  # Remove everything that is not a number or letter 
  temp <- str_replace_all(temp,"[^a-zA-Z\\s]", " ")
  # Remove stopwords
  temp <- removeWords(temp, stopwords('en'))
  # Shrink down to just one white space
  temp <- str_replace_all(temp,"[\\s]+", " ")
  # Split the string into words
  temp <- str_split(temp, " ")[[1]]
  temp <- stem_words(temp)
  # Get rid of trailing "" if necessary
  indexes <- which(temp == "")
  if(length(indexes) > 0){temp <- temp[-indexes]}
  # Get unique words
  return(paste(unique(temp),collapse = ' '))
}  


for(i in 1:NROW(r1))
{
  r1$CleanText[i] <- Clean_String(r1$text[i])
}

textdata = Sample_data[c("text","Brand")]
sentiment_scores = classify_polarity(r1)
Sentiment = as.data.frame(sentiment_scores[,3:4])
final_result = cbind(textdata,Sentiment)
colnames(final_result)= c("Tweets","Brand","Ratio","Polarity")

#Splitting the data

intermediate_result = cbind.data.frame(final_result,Sample_data[c("followers_count","friends_count","favourites_count","retweet_count")])
BrandNames <- split(intermediate_result, intermediate_result$Brand)


#Model 2

# model using Poisson regression model on Social Reach/Engagement score
require(ggplot2)
require(sandwich)
require(msm)

social_data = Sample_data[c("followers_count","friends_count","favourites_count","retweet_count")]
  
#Assign a score against each tweet 

for (i in 1:NROW(social_data)) {
  social_data$Score[i] = log(sum(social_data$followers_count[i],social_data$friends_count[i],social_data$favourites_count[i],social_data$retweet_count[i]))
}

summary(m1 <- glm(Score ~ followers_count + friends_count + favourites_count + retweet_count, family="poisson", data=social_data))

social_data$Score = m1$coefficients[1] + social_data$followers_count*m1$coefficients[2] + social_data$friends_count*m1$coefficients[3] + social_data$favourites_count*m1$coefficients[4] + social_data$retweet_count*m1$coefficients[5]


Combined_scores = data.frame(matrix(ncol = 6, nrow = NROW(intermediate_result)))
x = c("Text","Brand","SentimentRatio","SocialReachIndex","Sentiment","SocialReach")
colnames(Combined_scores) = x

Combined_scores$Text = intermediate_result$Tweets
Combined_scores$Brand = Sample_data$Brand
Combined_scores$SentimentRatio = intermediate_result$Ratio
Combined_scores$SentimentRatio = round(as.numeric(levels(intermediate_result$Ratio)[intermediate_result$Ratio]), 2 )
Combined_scores$SocialReachIndex = round(social_data$Score , 2)
Combined_scores$Sentiment = intermediate_result$Polarity

sr_cutoff = median(Combined_scores$SocialReachIndex)


for (i in 1:NROW(Combined_scores)) {
  if(Combined_scores$SocialReachIndex[i] > sr_cutoff) {
    Combined_scores$SocialReach[i] = "positive"
  }
  else if(Combined_scores$SocialReachIndex[i] < sr_cutoff) {
    Combined_scores$SocialReach[i] = "negative"
  }
  else if(Combined_scores$SocialReachIndex[i] == sr_cutoff) {
    Combined_scores$SocialReach[i] = "neutral"
  }
  else{
    Combined_scores$SocialReach[i] = "undefined"
  }
}

for (i in 1:NROW(Combined_scores)){
  if(Combined_scores$Text[i] == " "){
      Combined_scores$SentimentRatio[i] = 1
      Combined_scores$Sentiment[i] = "neutral"
  }
  
}

Aggregated.Table = Combined_scores

Aggregated.Table$Overall_Score = round(log(Aggregated.Table$SentimentRatio + Aggregated.Table$SocialReachIndex), 2)

write.csv(Aggregated.Table, "C:\\Personal\\My Projects\\Sentiment\\SocialSense_v2\\output\\final_modeloutput.csv", row.names = F)
