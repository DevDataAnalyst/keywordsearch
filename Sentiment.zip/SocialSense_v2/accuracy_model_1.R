# combined model performance
#Model 1

library("utils", lib.loc="C:/Personal/R/R-3.4.1/library")
library('RSentiment')
library('tm')
library('sentimentr')
library("textstem", lib.loc="C:/Personal/R/R-3.4.1/library")
library("stringr", lib.loc="C:/Personal/R/R-3.4.1/library")
library("sentiment", lib.loc="C:/Personal/R/R-3.4.1/library")
library("Rstem", lib.loc="C:/Personal/R/R-3.4.1/library")

# LOAD DATA FROM CSV

dat1 = read.csv("C:\\Personal\\My Projects\\Sentiment\\SocialSense_v2\\data\\sourcedata.csv",header=TRUE)


Sample_data = dat1[!(is.na(dat1$text) | dat1$text==""), ] # compile multiple datasets into 1(if present)

tweets = Sample_data[c("text","Brand")] #fetching two columns only

r1 = tweets
#View(r1)
r1$CleanText <- ""


# Text preprocessing function
Clean_String <- function(string){
  #symbol replace
  temp = str_replace_all(string, "[^[:alnum:]]", " ")
  # Lowercase
  temp <- tolower(string)
  # Remove everything that is not a number or letter 
  temp <- str_replace_all(temp,"[^a-zA-Z\\s]", " ")
  # Remove stopwords
  temp <- removeWords(temp, stopwords('en'))
  # Shrink down to just one white space
  temp <- str_replace_all(temp,"[\\s]+", " ")
  # Split the string into words
  temp <- str_split(temp, " ")[[1]]
  temp <- stem_words(temp)
  # Get rid of trailing "" if necessary
  indexes <- which(temp == "")
  if(length(indexes) > 0){temp <- temp[-indexes]}
  # Get unique words
  return(paste(unique(temp),collapse = ' '))
}  

#Clean all the texts row-wise

for(i in 1:NROW(r1))
{
  r1$CleanText[i] <- Clean_String(r1$text[i])
 
}  
#Sentiment Calculation and compiling within one dataframe

textdata = Sample_data[c("text","Brand")]
sentiment_scores = classify_polarity(r1)
Sentiment = as.data.frame(sentiment_scores[,3:4])
final_result = cbind(textdata,Sentiment)
colnames(final_result)= c("Tweets","Brand","Ratio","Polarity")

Accuracy_check = final_result[1:100,]

write.csv(Accuracy_check, "C:\\Personal\\My Projects\\Sentiment\\SocialSense_v2\\output\\Accuracy_model1output.csv", row.names = F)


